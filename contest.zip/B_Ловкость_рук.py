# ID посылки 90379557
# Ввод данных
def input_data():
    file_in = 'input.txt'
    data = []
    with open(file_in, 'r') as f:
        k = int(f.readline().strip())
        for i in range(4):
            data_string = list(f.readline().strip())
            data.extend(int(_) if _.isdigit() else 0 for _ in data_string)
    return k, data


# Основной блок
if __name__ == '__main__':
    k, data = input_data()
    t = max(data)
    score = 0
    # Цикл по играм в раунде
    for game in range(1, t+1):
        if 0 < data.count(game) <= k*2:
            score += 1
    print(score)
